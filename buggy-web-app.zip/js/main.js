// Buggy main.js
documment.getElementById("title").innerText = "Welcome";

document.getElementById("menuBtn").addEventListener("click", toggleMenu);

// toggleMenu is not defined
